@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="add-asset-container d-flex justify-content-between align-items-center">
                <h1>Purchase Invoices List</h1>
                <a href="{{ route('purchase_invoices.create') }}" class="add-asset-btn"><i class="fas fa-plus-circle" style="color: #4caf50; margin-right: 5px;"></i> Create Purchase Invoice</a>
            </div>
                
            <table class="table">
                <thead>
                    <tr>
                        <th>Asset Name</th>
                        <th>Purchase Date</th>
                        <th>Quantity</th>
                        <th>Total Cost</th>
                        
                    </tr>
                </thead>
                <tbody>
                    @foreach($invoices as $invoice)
                    <tr>
                        <td>{{ $invoice->asset->name }}</td>
                        <td>{{ $invoice->purchase_date }}</td>
                        <td>{{ $invoice->quantity }}</td>
                        <td>{{ $invoice->total_cost }}</td>
                       
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
