@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1>  Create Purchase Invoice</h1>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('purchase_invoices.store') }}">
                        @csrf

                        <div class="form-group">
                            <label for="asset_id">{{ __('Asset') }}</label>
                            <br>
                            <select class="form-control @error('asset_id') is-invalid @enderror" name="asset_id" required>
                                <option value="">Select an asset</option>
                                @foreach($assets as $asset)
                                    <option value="{{ $asset->id }}">{{ $asset->name }}</option>
                                @endforeach
                            </select>
                            @error('asset_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="purchase_date">{{ __('Purchase Date') }}</label>
                            <br>
                            <input type="date" class="form-control @error('purchase_date') is-invalid @enderror" name="purchase_date" required>
                            @error('purchase_date')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="quantity">{{ __('Quantity') }}</label>
                            <br>
                            <input type="number" class="form-control @error('quantity') is-invalid @enderror" name="quantity" required>
                            @error('quantity')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="total_cost">{{ __('Total Cost') }}</label>
                            <br>
                            <input type="number" step="0.01" class="form-control @error('total_cost') is-invalid @enderror" name="total_cost" required>
                            @error('total_cost')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">{{ __('Create Purchase Invoice') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
