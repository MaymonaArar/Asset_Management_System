@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
        <div class="add-asset-container d-flex justify-content-between align-items-center">
                <h1>Asset List</h1>
                
            </div>
                
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Purchase Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($assets as $asset)
                            <tr>
                                <td>{{ $asset->name }}</td>
                                <td>{{ $asset->description }}</td>
                                <td>{{ $asset->quantity }}</td>
                                <td>{{ $asset->purchase_date }}</td>
                                <td>
                                <a href="{{ route('assets.edit', $asset->id) }}"><i class="fas fa-edit" style="color: green; margin-right: 10px;"></i></a>
                                <a href="{{ route('assets.destroy', $asset->id) }}" onclick="event.preventDefault(); if (confirm('Are you sure you want to delete this asset?')) { document.getElementById('delete-form-{{ $asset->id }}').submit(); }"><i class="fas fa-trash-alt" style="color: yellow; margin-right: 10px;"></i></a>
                                <form id="delete-form-{{ $asset->id }}" action="{{ route('assets.destroy', $asset->id) }}" method="POST" style="display: none;">
                                    @csrf
                                    @method('DELETE')
                                </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
               
        </div>
        
    </div>
</div>
@endsection
