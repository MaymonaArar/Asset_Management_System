<!DOCTYPE html>
<html>
<head>
<title>Asset Management System</title>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    
</head>

<body>
<div class="navbar">
    
    <h1>Asset Management System</h1>
        
    <div class="nav-links">
        
        <a href="<?php echo e(route('assets.index')); ?>">Home</a>
        <a href="<?php echo e(route('assets.create')); ?>">Add Asset</a>
        <a href="<?php echo e(route('purchase_invoices.create')); ?>">Add Purchase Invoice</a>
        <a href="<?php echo e(route('purchase_invoices.index')); ?>">All Purchase Invoice</a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="logout-form">
    <?php echo csrf_field(); ?>
    <a href="#" class="logout-button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</form>


    </div>
</div>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
</body>
</html>
<?php /**PATH C:\Users\A\Asset_system_Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>