

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
        <div class="add-asset-container d-flex justify-content-between align-items-center">
                <h1>Asset List</h1>
                
            </div>
                
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Purchase Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($asset->name); ?></td>
                                <td><?php echo e($asset->description); ?></td>
                                <td><?php echo e($asset->quantity); ?></td>
                                <td><?php echo e($asset->purchase_date); ?></td>
                                <td>
                                <a href="<?php echo e(route('assets.edit', $asset->id)); ?>"><i class="fas fa-edit" style="color: green; margin-right: 10px;"></i></a>
                                <a href="<?php echo e(route('assets.destroy', $asset->id)); ?>" onclick="event.preventDefault(); if (confirm('Are you sure you want to delete this asset?')) { document.getElementById('delete-form-<?php echo e($asset->id); ?>').submit(); }"><i class="fas fa-trash-alt" style="color: yellow; margin-right: 10px;"></i></a>
                                <form id="delete-form-<?php echo e($asset->id); ?>" action="<?php echo e(route('assets.destroy', $asset->id)); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
               
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A\Asset_system_Laravel\resources\views/assets/index.blade.php ENDPATH**/ ?>