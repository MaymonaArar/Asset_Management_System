

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="add-asset-container d-flex justify-content-between align-items-center">
                <h1>Purchase Invoices List</h1>
                <a href="<?php echo e(route('purchase_invoices.create')); ?>" class="add-asset-btn"><i class="fas fa-plus-circle" style="color: #4caf50; margin-right: 5px;"></i> Create Purchase Invoice</a>
            </div>
                
            <table class="table">
                <thead>
                    <tr>
                        <th>Asset Name</th>
                        <th>Purchase Date</th>
                        <th>Quantity</th>
                        <th>Total Cost</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($invoice->asset->name); ?></td>
                        <td><?php echo e($invoice->purchase_date); ?></td>
                        <td><?php echo e($invoice->quantity); ?></td>
                        <td><?php echo e($invoice->total_cost); ?></td>
                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A\Asset_system_Laravel\resources\views/purchase_invoices/index.blade.php ENDPATH**/ ?>