<?php

namespace App\Http\Controllers;

use App\Models\PurchaseInvoice;
use Illuminate\Http\Request;
use App\Models\Asset; 

class PurchaseInvoiceController extends Controller
{
    public function index()
    {
        $invoices = PurchaseInvoice::all();
        return view('purchase_invoices.index', compact('invoices'));
    }

    public function create()
    {
        $assets = Asset::all();
        return view('purchase_invoices.create', compact('assets'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'asset_id' => 'required|exists:assets,id',
            'purchase_date' => 'required|date',
            'quantity' => 'required|integer|min:1',
            'total_cost' => 'required|numeric|min:0',
        ]);

        PurchaseInvoice::create($validatedData);

         // Update the asset quantity
         $asset = Asset::find($validatedData['asset_id']);
         $asset->quantity += $validatedData['quantity'];
         $asset->save();
         
        return redirect()->route('assets.index')->with('success', 'Purchase invoice created successfully.');
    
    }

    public function edit(PurchaseInvoice $invoice)
    {
        $assets = Asset::all();
        return view('purchase_invoices.edit', compact('invoice', 'assets'));
    }

    public function update(Request $request, PurchaseInvoice $invoice)
    {
        $validatedData = $request->validate([
            'asset_id' => 'required|exists:assets,id',
            'purchase_date' => 'required|date',
            'quantity' => 'required|integer|min:1',
            'total_cost' => 'required|numeric|min:0',
        ]);

        $invoice->update($validatedData);

        return redirect()->route('purchase_invoices.index')->with('success', 'Purchase invoice updated successfully!');
    }

    public function destroy(PurchaseInvoice $invoice)
    {
        $invoice->delete();

        return redirect()->route('purchase_invoices.index')->with('success', 'Purchase invoice deleted successfully!');
    }
}

