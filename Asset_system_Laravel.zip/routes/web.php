<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/




use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\PurchaseInvoiceController;

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');

// Authentication Routes
//Route::post('/login', [LoginController::class, 'login']);
Route::post('/login', [LoginController::class, 'login'])->name('login');
Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register']);
Route::get('/logout', [LoginController::class, 'logout'])->name('logout'); 


// Asset Management Routes
Route::middleware('auth')->group(function () {
    Route::get('/assets', [AssetController::class, 'index'])->name('assets.index');
    Route::resource('assets', AssetController::class);
    Route::get('/purchase_invoices/create', [PurchaseInvoiceController::class, 'create'])->name('purchase_invoices.create');
    Route::post('/purchase_invoices', [PurchaseInvoiceController::class, 'store'])->name('purchase_invoices.store');
    Route::get('/purchase_invoices', [PurchaseInvoiceController::class, 'index'])->name('purchase_invoices.index'); 
});


